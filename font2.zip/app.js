/*var cluster = require('cluster');
var numCPUs = require('os').cpus().length;	*/
var util = require('util');
var events = require('events');
var multiparty = require("multiparty");
var mimeType = require('mime-types');
var WebSocket = require('ws');
var http = require('http');
var fs = require('fs');
var schedule = require('node-schedule');
var amqp = require('amqplib/callback_api');
var ip = require('ip');
var url = require('url');
var coreLibs = require('tds-node-core/libs');

var properties = coreLibs.properties;
var conexaoRabbitMq = null;
var URL_RABBITMQ = properties.get('URL_RABBITMQ');
var	PORTA_BARRAMENTO = 5000;
var APPLICATION_JSON = "content-type: application/json; charset: utf-8";
var NO_REPLY = "NO_REPLY";
var NOOP = "NOOP";
var ASSOCIAR_QUEUE_DE_RECEBIMENTO_DE_MENSAGEM = "ASSOCIAR_QUEUE_DE_RECEBIMENTO_DE_MENSAGEM";
var TEMPO_PING = 1500;

var diretorioScript = __filename.slice(0, __dirname.length + 1) + "logs/";
var nomeArquivoLogAnterior = __filename.slice(__dirname.length + 1) + "_anterior.log";
var nomeArquivoLogAtual = __filename.slice(__dirname.length + 1) + "_atual.log";
var CONSOLE_LOG_ANTERIOR = console.log;
var CONSOLE_INFO_ANTERIOR = console.info;
var CONSOLE_DEBUG_ANTERIOR = console.debug;
var CONSOLE_ERROR_ANTERIOR = console.error;

schedule.scheduleJob({hour: 0, minute: 0}, backupLogDiaAnterior);

console.log = function(msg)
{
	CONSOLE_LOG_ANTERIOR("[LOG      ] " + getDataHoraAtual() + " " + JSON.stringify(msg));
	gravarLog("[LOG      ] " + getDataHoraAtual() + " " + JSON.stringify(msg));
};

console.info = function(msg)
{
	CONSOLE_INFO_ANTERIOR("[INFO     ] " + getDataHoraAtual() + " " + JSON.stringify(msg));
	gravarLog("[INFO     ] " + getDataHoraAtual() + " " + JSON.stringify(msg));
};

console.debug = function(msg)
{
	CONSOLE_DEBUG_ANTERIOR("[DEBUG    ] " + getDataHoraAtual() + " " + JSON.stringify(msg));
	gravarLog("[DEBUG    ] " + getDataHoraAtual() + " " + JSON.stringify(msg));
};

console.error = function(msg)
{
	CONSOLE_ERROR_ANTERIOR("[ERROR    ] " + getDataHoraAtual() + " " + JSON.stringify(msg));
	gravarLog("[ERROR    ] " + getDataHoraAtual() + " " + JSON.stringify(msg));
};

function gravarLog(texto)
{
    /*try
    {
		if (!fs.existsSync(diretorioScript))
		{
			fs.mkdirSync(diretorioScript);
		}
		fs.appendFile(diretorioScript + "/" + nomeArquivoLogAtual, texto + "\n", function(err)
		{
			if (err)
			{
				CONSOLE_ERROR_ANTERIOR("[ERROR    ] " + getDataHoraAtual() + " Erro ao gravar log em arquivo: ");
				CONSOLE_LOG_ANTERIOR(err);
			}
		});
    }
    catch(err)
    {
        CONSOLE_ERROR_ANTERIOR("[ERROR    ] " + getDataHoraAtual() + " Erro ao gravar log em arquivo: ");
		CONSOLE_LOG_ANTERIOR(err);
    }*/
}

function backupLogDiaAnterior()
{
	/*try
	{
		fs.unlink(diretorioScript + "/" + nomeArquivoLogAnterior);
		fs.rename(diretorioScript + "/" + nomeArquivoLogAtual, diretorioScript + "/" + nomeArquivoLogAnterior);
	}
	catch(err)
	{
        CONSOLE_ERROR_ANTERIOR("[ERROR    ] " + getDataHoraAtual() + " Erro ao renomear log anterior: ");
		CONSOLE_LOG_ANTERIOR(err);
	}*/
}

function getDataHoraAtual()
{
	var dataAtual     = new Date();
	var ano           = preencherZerosEsquerda(dataAtual.getFullYear()    , 4);
	var mes           = preencherZerosEsquerda(dataAtual.getMonth() + 1   , 2);
	var dia           = preencherZerosEsquerda(dataAtual.getDate()        , 2);
	var hora          = preencherZerosEsquerda(dataAtual.getHours()       , 2);
	var minuto        = preencherZerosEsquerda(dataAtual.getMinutes()     , 2);
	var segundo       = preencherZerosEsquerda(dataAtual.getSeconds()     , 2);
	//var milissegundos = preencherZerosEsquerda(dataAtual.getMilliseconds(), 3);
	var milissegundos = preencherZerosEsquerda("0", 3);
	return ano + "-" + mes + "-" + dia + " " + hora + ":" + minuto + ":" + segundo + "." + milissegundos;
}

function preencherZerosEsquerda(txt, quantidadeDigitos)
{
	txt = "" + txt;
	while(txt.length < quantidadeDigitos)
	{
		txt = "0" + txt;
	}
	return txt;
}

module.exports = ServidorBarramentoNode =
{
	servicosBarramento : []
};

function tratarPongServico(ch, nomeQueue, msg)
{
	try
	{
		if (!msg) // QUANDO a Queue É EXCLUÍDA, ENVIA UMA MENSAGEM NULA E PÁRA O SCRIPT
		{
			return;
		}
		validarMensagem(nomeQueue, msg);
		var mensagem = JSON.parse(msg.content.toString());
		console.log("Mensagem recebida com sucesso no Queue " + nomeQueue + " (" + JSON.stringify(mensagem) + ")");
		for (var pathServico in ServidorBarramentoNode.servicosBarramento)
		{
			var servico = ServidorBarramentoNode.servicosBarramento[pathServico];
			var servidores = servico.servidores;
			for (var i = 0, size = servico.servidores.length; i < size; i++)
			{
				if (servidores[i].url === mensagem.data)
				{
					servidores[i].retornouPing = true; // O PING RETORNOU
					servidores[i].ativo = true;
					servico.ativo = true;
				}
			}
		}
	}
	catch(error)
	{
		console.log("" + error);
	}
	ch.ack(msg);
}

function publicarMonitoracaoDeServicos(ch)
{
	var mensagemMonitoracao = 
	{
		"type": "MONITORACAO_DE_SERVICOS",
		"replyTo": NO_REPLY,
		"data": ServidorBarramentoNode.servicosBarramento
	};
	publicarMensagemExchange(ch, "MONITORACAO_DE_SERVICOS", JSON.stringify(mensagemMonitoracao));
}

function atualizarEstadoVerificandoRetornoPingChamadaAnterior(ch)
{
	for (var pathServico in ServidorBarramentoNode.servicosBarramento)
	{
		var servico = ServidorBarramentoNode.servicosBarramento[pathServico];
		var servidores = servico.servidores;
		servico.ativo = false;
		for (var i = 0, size = servico.servidores.length; i < size; i++)
		{
			if (servidores[i].retornouPing) // SE O PING ESTÁ TRUE, ENTÃO A MENSAGEM RETORNOU PELA QUEUE PONG TRATADA NA FUNÇÃO tratarPongServico (ACIMA). O SERVIÇO ESTÁ ONLINE
			{
				servidores[i].ativo = true;
				servico.ativo = true; // SE AO MENOS UM SERVIDOR ESTÁ OK, O SERVIÇO ESTÁ ATIVO
			}
			else
			{
				servidores[i].ativo = false;
			}
			console.log((servidores[i].ativo ? "[ON ] " : "[OFF] ") + servidores[i].url);
		}
		console.log((servico.ativo ? "[ON ] " : "[OFF] ") + pathServico);
	}
	publicarMonitoracaoDeServicos(ch);
}

function limparQueue(ch, nomeQueue)
{
	//ch.assertQueue(nomeQueue, {durable: true, persistent: true, messageTtl: 86400000});
	ch.purgeQueue(nomeQueue);
}

function criarMonitorServicos(ch)
{
	associarCallbackQueueRecebimentoMensagens(ch, "PONG", tratarPongServico);
	setInterval(function()
	{
		atualizarEstadoVerificandoRetornoPingChamadaAnterior(ch);
		for (var pathServico in ServidorBarramentoNode.servicosBarramento)
		{
			var servico = ServidorBarramentoNode.servicosBarramento[pathServico];
			servico.retornouPing = false; // AINDA NÃO TENHO O RETORNO DESTE PING
			var servidores = servico.servidores;
			for (var i = 0, size = servico.servidores.length; i < size; i++)
			{
				var mensagemPing = 
				{
					"type": "PING",
					"replyTo": "PONG",
					"data": servidores[i].url
				};
				servidores[i].retornouPing = false; // AINDA NÃO TENHO O RETORNO DESTE PING
				limparQueue(ch, servidores[i].url + "_PING");
				publicarMensagemQueue(ch, servidores[i].url + "_PING", JSON.stringify(mensagemPing));
			}
		}
	}, TEMPO_PING);
}

function parseMultipart(requisicao, resposta)
{
	var eventEmitter = new events.EventEmitter();
	var form = new multiparty.Form();

	form.parse(requisicao, function(error, fields, files)
	{
		var mensagem = 
		{
			"data":
			{
				"fields" : {},
				"files" : {}
			}
		};
		if (error)
		{
			console.log("" + error);
			gerarErroHttp(resposta, httpStatus, "Erro ao processar multipart do serviço " + requisicao.method + " " + error)
		}
		else
		{
			for (var props in fields)
			{
				if (fields[props].length == 1)
				{
					mensagem.data.fields[props] = fields[props][0];
				}
				else
				{
					mensagem.data.fields[props] = fields[props];
				}
			}
			for (var props in files)
			{
				mensagem.data.files[props] = files[props];
			}
		}
		eventEmitter.emit("end", mensagem);
	});
	return eventEmitter;
}

function gerarErroHttp(resposta, httpStatus, mensagem)
{
	var txtMensagem = null;
	if (!mensagem)
	{
		txtMensagem = "null";
	}
	else
	{
		txtMensagem = mensagem.toString();
	}
	var mensagemErro =
	{
		"type" : "MENSAGEM_DE_ERRO",
		"data" : txtMensagem
	}
	resposta.writeHead(httpStatus, APPLICATION_JSON);
	resposta.write(JSON.stringify(mensagemErro));
	resposta.end();	
	console.log("Error: (" + httpStatus + ") " + txtMensagem);
}

function excluirQueue(ch, nomeQueue)
{
	ch.deleteQueue(nomeQueue);
}

function tratarRetornoHttp(ch, nomeQueue, msg, resposta)
{
	try
	{
		if (!msg) // QUANDO O Queue É EXCLUÍDO, ENVIA UMA MENSAGEM NULA E PÁRA O SCRIPT
		{
			return;
		}
		validarMensagem(nomeQueue, msg);
		console.log("Mensagem recebida com sucesso no Queue " + nomeQueue + " (" + msg.content.toString() + ")");
		resposta.writeHead(200, APPLICATION_JSON);
		resposta.write(msg.content.toString());
		resposta.end();
		ch.ack(msg);
		excluirQueue(ch, nomeQueue);
	}
	catch(error)
	{
		ch.ack(msg);
		excluirQueue(ch, nomeQueue);
		gerarErroHttp(resposta, 500, "" + error);
	}
}

function parseRequest(requisicao, callback)
{
	var mensagem = '';
	requisicao.on('data', function (chunk)
	{
		mensagem += chunk;
	});
	requisicao.on('end', function ()
	{
		try
		{
			JSON.parse(mensagem);
		}
		catch(error)
		{
			requisicao.emit('error', new Error("O valor informado na entrada não é um objeto JSON válido (" + mensagem + ") [" + error + "]"));
		}
		try
		{
			callback(mensagem);
		}
		catch(error)
		{
			requisicao.emit('error', error);
		}
	});
}

function executarServicoHttp(ch, pathname, requisicao, resposta)
{
	if (ServidorBarramentoNode.servicosBarramento[pathname])
	{
		var contentType = requisicao.headers["content-type"];
		if (!contentType)
		{
			contentType = "application/json";
		}		
		if (requisicao.method !== 'POST')
		{
			gerarErroHttp(resposta, 405, "Método não permitido. Este servidor node não foi projetado para aceitar requisições com métodos diferentes de POST");
			return;
		}
		else if (!ServidorBarramentoNode.servicosBarramento[pathname])
		{
			gerarErroHttp(resposta, 500, "Erro: Serviço " + pathname + " inexistente.");
			return;
		}
		else if (ServidorBarramentoNode.servicosBarramento[pathname].tipoServico === "APPLICATION" 
			&& !ip.isEqual(requisicao.connection.remoteAddress, ip.address()))
		{
			gerarErroHttp(resposta, 500, "Erro: Serviço " + pathname + " é um serviço interno do barramento e não pode ser acessado pela sessão do cliente.");
			return;
		}		
		else if (!ServidorBarramentoNode.servicosBarramento[pathname].ativo)
		{
			gerarErroHttp(resposta, 500, "Erro: Serviço " + pathname + " inoperante.");
			return;
		}
		else if (contentType.indexOf("application/json") === 0)
		{
			var cancelTimeout = setInterval(function()
			{
				if (!ServidorBarramentoNode.servicosBarramento[pathname].ativo)
				{
					gerarErroHttp(resposta, 500, "Erro: Serviço " + pathname + " inoperante.");
					clearInterval(cancelTimeout);
				}
			}, TEMPO_PING);
			resposta.on('error', function(error)
			{
				console.log("" + error);
			});
			requisicao.on('error', function(error)
			{
				gerarErroHttp(resposta, 500, "" + error);
			});
			parseRequest(requisicao, function(msg) // Obs: Já valida o json da mensagem enviada neste parse
			{
				console.log("Publicando mensagem " + msg + " no Queue " + pathname);
				var queueTela = requisicao.connection.remoteAddress + "_Tela_" + (new Date().getTime());
				var mensagem = JSON.parse(msg);
				mensagem.replyTo = queueTela;
				
				ch.assertQueue(queueTela, {durable: true, persistent: true, messageTtl: 60000}); // 1 MIN
				associarCallbackQueueRecebimentoMensagens(ch, queueTela, tratarRetornoHttp, resposta);
				
				publicarMensagemQueue(ch, pathname, JSON.stringify(mensagem));
			});
		}
		else if (contentType.indexOf("multipart/form-data") === 0)
		{
			var cancelTimeout = setInterval(function()
			{
				if (!ServidorBarramentoNode.servicosBarramento[pathname].ativo)
				{
					gerarErroHttp(resposta, 500, "Erro: Serviço " + pathname + " inoperante.");
					clearInterval(cancelTimeout);
				}
			}, TEMPO_PING);
			resposta.on('error', function(error)
			{
				console.log("" + error);
			});
			requisicao.on('error', function(error)
			{
				gerarErroHttp(resposta, 500, "" + error);
			});
			parseMultipart(requisicao, resposta)
			.on('end', function(mensagem)
			{
				console.log("Publicando mensagem " + JSON.stringify(mensagem) + " no Queue " + pathname);
				var queueTela = requisicao.connection.remoteAddress + "_Tela_" + (new Date().getTime());
				mensagem.type = "MULTIPART";
				mensagem.replyTo = queueTela;

				ch.assertQueue(queueTela, {durable: true, persistent: true, messageTtl: 60000}); // 1 MIN				
				associarCallbackQueueRecebimentoMensagens(ch, queueTela, tratarRetornoHttp, resposta);
				
				publicarMensagemQueue(ch, pathname, JSON.stringify(mensagem));
			});
		}
		else
		{
			gerarErroHttp(resposta, 400, "[BARRAMENTO] Este serviço não foi projetado para aceitar entrada de dados diferente de multipart/form-data ou application/json. Entrada informada: " + requisicao.headers["content-type"]);
		}
	}
	else
	{
		gerarErroHttp(resposta, 404, "Serviço não encontrado.");
	}
}

function lerArquivoDiretorioSrc(pathname, resposta)
{
	fs.readFile("src/" + pathname, function(error, data)
	{
		if (error)
		{
			console.log("Erro ao ler arquivo em disco");
			gerarErroHttp(resposta, 404, "Oooops!!! Arquivo não encontrado");
		}
		else
		{
			console.log("Sucesso ao ler arquivo em disco");
			var tipoConteudo = mimeType.lookup("src/" + pathname) || 'application/octet-stream';
			resposta.writeHead(200, {'Content-Type': tipoConteudo});
			resposta.write(data);
			resposta.end();
		}
	});	
}

function criarServidorHttp(ch)
{
	var servidorHttp = http.createServer(function(requisicao, resposta)
	{
		var pathname = url.parse(requisicao.url).pathname;
		console.log("Solicitação HTTP para " + pathname);
		if (pathname === "/")
		{
			pathname = "/index.html";
		}
		if (pathname.indexOf("/servicos") === 0)
		{
			executarServicoHttp(ch, pathname, requisicao, resposta);
		}
		else
		{
			lerArquivoDiretorioSrc(pathname, resposta);
		}
	});
	return servidorHttp;
}

function validarMensagem(nomeQueue, msg)
{
	var mensagem = null;
	try
	{
		if (msg.content) // Para extrair o txt em formato json do objeto enviado pela Rabbit quando for necessário
		{
			msg = msg.content.toString();
		}
		mensagem = JSON.parse(msg);
	}
	catch(error)
	{
		throw new Error("A mensagem enviada para o Queue " + nomeQueue + " não é um objeto JSON válido (" + msg + "} [" + error + "]");
	}	
	if (!mensagem.type)
	{
		throw new Error("O campo type da mensagem enviada para o Queue " + nomeQueue + " não é um valor válido. (" + JSON.stringify(mensagem) + ")");
	}
	if (!mensagem.replyTo)
	{
		throw new Error("O campo replyTo da mensagem enviada para o Queue " + nomeQueue + " não é um valor válido. (" + JSON.stringify(mensagem) + ")");
	}
}

function ligarQueueExchange(ch, typeMessage, nomeQueue)
{
	ch.bindQueue(nomeQueue, typeMessage, '');
}

function desligarQueueExchange(ch, typeMessage, nomeQueue)
{
	ch.unbindQueue(nomeQueue, typeMessage, '');
}

function publicarMensagemQueue(ch, nomeQueue, mensagem)
{
	console.log("Publicando mensagem " + mensagem + " no Queue " + nomeQueue);
	validarMensagem(nomeQueue, mensagem);
	//, {durable: true, persistent: true, maxLength: 1/*, messageTtl: 86400000*/}
	//ch.assertQueue(nomeQueue, {durable: true, persistent: true, messageTtl: 86400000});
	ch.sendToQueue(nomeQueue, Buffer.from(mensagem));
}

function enviarMensagemCriacaoQueueRecebimentoMensagem(ch, nomeQueue, mensagem)
{
	var servidorEncontrado = false;
	for (var pathServico in ServidorBarramentoNode.servicosBarramento)
	{
		var servico = ServidorBarramentoNode.servicosBarramento[pathServico];
		var servidores = servico.servidores;
		for (var i = 0, size = servico.servidores.length; i < size; i++)
		{
			if (servidores[i].url === mensagem.replyTo)
			{
				servidorEncontrado = true;
				// CANAL DE RECEBIMENTO DE MENSAGENS DE SERVIÇOS DESTE TIPO
				var criarQueueDeRecebimentoDeMensagem = 
				{
					"type": ASSOCIAR_QUEUE_DE_RECEBIMENTO_DE_MENSAGEM,
					"replyTo": NO_REPLY,  // ESTA MENSAGEM NÃO É PASSÍVEL DE RESPOSTA
					"data": pathServico
				};
				publicarMensagemQueue(ch, servidores[i].url, JSON.stringify(criarQueueDeRecebimentoDeMensagem));

				// CANAL DE PING DESTE SERVICO
				var criarQueueDeRecebimentoDePing = 
				{
					"type": ASSOCIAR_QUEUE_DE_RECEBIMENTO_DE_MENSAGEM,
					"replyTo": NO_REPLY,  // ESTA MENSAGEM NÃO É PASSÍVEL DE RESPOSTA
					"data": servidores[i].url + "_PING"
				};
				publicarMensagemQueue(ch, servidores[i].url, JSON.stringify(criarQueueDeRecebimentoDePing));
			}
		}
	}
	if (!servidorEncontrado)
	{
		throw new Error("Mensagem recebida mas o servidor distribuido " + mensagem.replyTo + " não foi encontrado no json de serviços " + nomeQueue + " (" + JSON.stringify(mensagem) + ")");
	}
}

function solicitarServicoDistribuidoCriarQueueDeRecebimentoDeMensagem(ch, nomeQueue, msg)
{
	try
	{
		if (!msg) // QUANDO a Queue É EXCLUÍDA, ENVIA UMA MENSAGEM NULA E PÁRA O SCRIPT
		{
			return;
		}
		validarMensagem(nomeQueue, msg);
		var mensagem = JSON.parse(msg.content.toString());
		console.log("Mensagem recebida com sucesso no Queue " + nomeQueue + " (" + JSON.stringify(mensagem) + ")");
		enviarMensagemCriacaoQueueRecebimentoMensagem(ch, nomeQueue, mensagem);
	}
	catch(error)
	{
		console.log("" + error);
	}
	ch.ack(msg);
}

var channelPublicarMensagemExchange = undefined;
function publicarMensagemExchange(ch, typeMessage, mensagem)
{
	console.log("Publicando mensagem " + mensagem + " no Exchange " + typeMessage);
	validarMensagem(typeMessage, mensagem);
	conexaoRabbitMq.createChannel(function(error, ch)
	{
		if (error)
		{
			console.log("" + error);
		}
		else
		{
			ch.assertExchange(typeMessage, 'fanout', {durable: true, persistent: true});
			ch.bindQueue(NOOP, typeMessage, '');
			ch.publish(typeMessage, '', Buffer.from(mensagem));
			ch.close();
		}
	});
/*	if (!channelPublicarMensagemExchange)
	{
		conexaoRabbitMq.createChannel(function(error, ch)
		{
			if (error)
			{
				console.log("" + error);
			}
			else
			{
				channelPublicarMensagemExchange = ch;
				channelPublicarMensagemExchange.assertExchange(typeMessage, 'fanout', {durable: true, persistent: true});
				channelPublicarMensagemExchange.bindQueue(NOOP, typeMessage, '');
				channelPublicarMensagemExchange.publish(typeMessage, '', Buffer.from(mensagem));
			}
		});
	}
	else
	{
		channelPublicarMensagemExchange.assertExchange(typeMessage, 'fanout', {durable: true, persistent: true});
		channelPublicarMensagemExchange.bindQueue(NOOP, typeMessage, '');
		channelPublicarMensagemExchange.publish(typeMessage, '', Buffer.from(mensagem));
	}*/
}

function tratarPublicacaoMensagem(ch, nomeQueue, msg)
{
	try
	{
		if (!msg) // QUANDO a Queue É EXCLUÍDA, ENVIA UMA MENSAGEM NULA E PÁRA O SCRIPT
		{
			return;
		}
		validarMensagem(nomeQueue, msg);
		var mensagem = JSON.parse(msg.content.toString());
		var queueDestino = mensagem.type;
		console.log("Mensagem recebida com sucesso no Queue " + nomeQueue + " (" + JSON.stringify(mensagem) + ")");
		if (!mensagem.replyTo)
		{
			mensagem.replyTo = NO_REPLY;
		}
		if (mensagem.oldType)
		{
			mensagem.type = mensagem.oldType;
		}
		publicarMensagemExchange(ch, queueDestino, JSON.stringify(mensagem));
	}
	catch(error)
	{
		console.log("" + error);
	}
	ch.ack(msg);
}

function associarCallbackQueueRecebimentoMensagens(ch, nomeQueue, callback, respostaHttp, socket)
{
	//ch.assertQueue(nomeQueue, {durable: true, persistent: true, messageTtl: 86400000}); // 1 DIA
	ch.consume(nomeQueue, function(msg)
	{
		if (respostaHttp)
		{
			callback(ch, nomeQueue, msg, respostaHttp);
		}
		else
		{
			callback(ch, nomeQueue, msg, socket);
		}
	},
	{
		noAck: false
	});
}

function gerarErroWebSocket(socket, mensagem)
{
	var txtMensagem = null;
	if (!mensagem)
	{
		txtMensagem = "null";
	}
	else
	{
		txtMensagem = mensagem.toString();
	}
	var mensagemErro =
	{
		"type" : "MENSAGEM_DE_ERRO",
		"data" : txtMensagem
	}
	if (socket.readyState === WebSocket.OPEN)
	{
		socket.send(JSON.stringify(mensagemErro));
	}
	console.log("" + JSON.stringify(mensagemErro));
}

function tratarRetornoWebsocket(ch, nomeQueue, msg, wsBarramento)
{
	try
	{
		if (!msg) // QUANDO O Queue É EXCLUÍDO, ENVIA UMA MENSAGEM NULA E PÁRA O SCRIPT
		{
			return;
		}
		validarMensagem(nomeQueue, msg);
		console.log("Mensagem recebida com sucesso no Queue " + nomeQueue + " (" + msg.content.toString() + ")");
		if (wsBarramento.readyState === WebSocket.OPEN)
		{
			wsBarramento.send(msg.content.toString());
		}
		else
		{
			wsBarramento.terminate();
			excluirQueue(ch, nomeQueue);
		}
		ch.ack(msg);
	}
	catch(error)
	{
		ch.ack(msg);
		gerarErroWebSocket(wsBarramento, "" + error);
	}
}

function executarServicoWebSocket(ch, pathname, wsBarramento, requisicao)
{
	if (!ServidorBarramentoNode.servicosBarramento[pathname])
	{
		gerarErroWebSocket(wsBarramento, "Erro: Serviço " + pathname + " inexistente.");
		return;
	}
	else if (ServidorBarramentoNode.servicosBarramento[pathname].tipoServico === "APPLICATION" 
		&& !ip.isEqual(requisicao.connection.remoteAddress, ip.address()))
	{
		gerarErroWebSocket(wsBarramento, "Erro: Serviço " + pathname + " é um serviço interno do barramento e não pode ser acessado pela sessão do cliente.");
		return;
	}		
	else if (!ServidorBarramentoNode.servicosBarramento[pathname].ativo)
	{
		gerarErroWebSocket(wsBarramento, "Erro: Serviço " + pathname + " inoperante.");
	}
	else
	{
		/*var cancelTimeout = setInterval(function()
		{
			if (!ServidorBarramentoNode.servicosBarramento[pathname].ativo)
			{
				wsBarramento.terminate();
				clearInterval(cancelTimeout);
			}
		}, TEMPO_PING);*/
		
		// Agenda expiração da sessão se ficar 30 min sem atividade de mensagens
		var cancelTimeoutExpiracao = setTimeout(function()
		{
			wsBarramento.terminate();
		}, 1800000); // EXPIRA SESSÃO SE ESTIVER 30 MIN SEM ATIVIDADE
		
		var queueTela = requisicao.connection.remoteAddress + "_Tela_" + (new Date().getTime());
		ch.assertQueue(queueTela, {durable: true, persistent: true, messageTtl: 60000}); // 1 MIN
		associarCallbackQueueRecebimentoMensagens(ch, queueTela, tratarRetornoWebsocket, null, wsBarramento);
		ligarQueueExchange(ch, "BROADCAST_FROM_" + pathname, queueTela);
		wsBarramento.on("error", function(err)
		{
			console.log("" + error);
			excluirQueue(ch, queueTela);
			desligarQueueExchange(ch, "BROADCAST_FROM_" + pathname, queueTela);
		});
		wsBarramento.on("message", function(msg)
		{
			try
			{
				// Reagenda expiração da sessão se ficar 30 min sem atividade de mensagens
				clearTimeout(cancelTimeoutExpiracao);
				cancelTimeoutExpiracao = setTimeout(function()
				{
					wsBarramento.terminate();
				}, 1800000); // EXPIRA SESSÃO SE ESTIVER 30 MIN SEM ATIVIDADE

				var mensagem = JSON.parse(msg);
				mensagem.replyTo = queueTela;			
				publicarMensagemQueue(ch, pathname, JSON.stringify(mensagem));
			}
			catch(error)
			{
				console.log("" + error);
				gerarErroWebSocket(wsBarramento, "Error: O valor informado na entrada não é um objeto JSON válido (" + msg + ") [" + error + "]");
			}
		});
		wsBarramento.on("close", function()
		{
			excluirQueue(ch, queueTela);
			desligarQueueExchange(ch, "BROADCAST_FROM_" + pathname, queueTela);
		});
	}
}

function criarServidorWebSocket(ch, servidorHttp)
{
	var servidorWebSocket = new WebSocket.Server(
	{
		server: servidorHttp,
		clientTracking: true,
		verifyClient: function(info)
		{
			var pathname = url.parse(info.req.url).pathname;
			console.log('Conexão socket para ' + pathname);
			if (pathname.indexOf('/servicos') === 0)
			{
				console.log("Aceitar conexão socket. (" + servidorWebSocket.clients.size + " total de conexões)");
				return true;
			}
			else
			{
				console.log("Recusar conexão socket. (" + servidorWebSocket.clients.size + " total de conexões)");
				return false;
			}
		}
	});

	servidorWebSocket.on('connection', function (wsBarramento, requisicao)
	{
		var pathname = url.parse(requisicao.url).pathname;
		executarServicoWebSocket(ch, pathname, wsBarramento, requisicao);
	});

	servidorWebSocket.on('error', function (error)
	{
		console.log("Erro: " + error);
	});	

	return servidorWebSocket;
}

function excluirExchange(ch, nomeExchange)
{
	console.log("Excluindo exchange " + nomeExchange);
	ch.deleteExchange(nomeExchange);
}

function criarQueueExchangeDeMensagensParaServicos(ch)
{
	console.log("Criando queue PONG");
	ch.assertQueue("PONG", {durable: true, persistent: true, messageTtl: 30000}); // 30 segs
	console.log("Criando queue NOTIFICACAO_SERVICO_ONLINE");
	ch.assertQueue("NOTIFICACAO_SERVICO_ONLINE", {durable: true, persistent: true, messageTtl: 30000}); // 30 segs

	console.log("Criando queue NOOP");
	ch.assertQueue(NOOP, {durable: true, persistent: true, maxLength: 0});
	console.log("Criando queue NO_REPLY");
	ch.assertQueue(NO_REPLY, {durable: true, persistent: true, maxLength: 1});
	console.log("Criando queue PUBLICACAO_MENSAGEM");
	ch.assertQueue("PUBLICACAO_MENSAGEM", {durable: true, persistent: true, messageTtl: 86400000}); // 1 DIA

	for (var pathServico in ServidorBarramentoNode.servicosBarramento)
	{
		var servico = ServidorBarramentoNode.servicosBarramento[pathServico];
		var receberMensagensDoTipo = servico.receberMensagensDoTipo;
		for (var j = 0, size1 = servico.servidores.length; j < size1; j++)
		{
			console.log("Criando queue " + servico.servidores[j].url);
			ch.assertQueue(servico.servidores[j].url, {durable: true, persistent: true, messageTtl: 86400000}); // 1 DIA
			console.log("Criando queue " + servico.servidores[j].url + "_PING");
			ch.assertQueue(servico.servidores[j].url + "_PING", {durable: true, persistent: true, maxLength: 10, messageTtl: 30000}); // 30 segs
		}
		if (servico.tipoServico === "SESSION")
		{
			console.log("Criando queue " + pathServico);
			ch.assertQueue(pathServico, {durable: true, persistent: true, messageTtl: 1800000}); // 30 MIN
			console.log("Criando exchange " + "BROADCAST_FROM_" + pathServico);
			ch.assertExchange("BROADCAST_FROM_" + pathServico, 'fanout', {durable: true, persistent: true, messageTtl: 1800000}); // 30 MIN
		}
		else // APPLICATION
		{
			console.log("Criando queue " + pathServico);
			ch.assertQueue(pathServico, {durable: true, persistent: true, messageTtl: 86400000}); // 1 DIA
			// APPLICATION EM TEORIA NÃO TEM BROADCAST
			console.log("Criando exchange " + "BROADCAST_FROM_" + pathServico);
			ch.assertExchange("BROADCAST_FROM_" + pathServico, 'fanout', {durable: true, persistent: true, messageTtl: 86400000}); // 1 DIA
		}
		for (var i = 0, size = receberMensagensDoTipo.length; i < size; i++)
		{
			console.log("Criando exchange " + receberMensagensDoTipo[i]);
			ch.assertExchange(receberMensagensDoTipo[i], 'fanout', {durable: true, persistent: true});
			ligarQueueExchange(ch, receberMensagensDoTipo[i], pathServico);
		}
	}
}

// TODO: DESEJÁVEL LIMPAR OS EXCHANGES NÃO UTILIZADOS PELO BARRAMENTO E NÃO DEFINIDOS NO JSON DE SERVIÇOS
function excluirTodosExchangeDeMensagensParaServicos(ch)
{
	for (var pathServico in ServidorBarramentoNode.servicosBarramento)
	{
		var servico = ServidorBarramentoNode.servicosBarramento[pathServico];
		var receberMensagensDoTipo = servico.receberMensagensDoTipo;
		excluirExchange(ch, "BROADCAST_FROM_" + pathServico);
		for (var i = 0, size = receberMensagensDoTipo.length; i < size; i++)
		{
			excluirExchange(ch, receberMensagensDoTipo[i]);
		}
	}
}

function iniciarServidorBarramentoNode()
{
	var jsonServicos = fs.readFileSync("./config/servicos_barramento.json", "utf8");
	while (jsonServicos.indexOf('$IP_BARRAMENTO') != -1)
	{
		jsonServicos = jsonServicos.replace('$IP_BARRAMENTO', ip.address());
	}
	ServidorBarramentoNode.servicosBarramento = JSON.parse(jsonServicos);
	
	amqp.connect(URL_RABBITMQ, function(error, conn)
	{
		if (error)
		{
			console.log("" + error);
		}
		else
		{
			conexaoRabbitMq = conn;
			conexaoRabbitMq.createChannel(function(error, ch)
			{
				if (error)
				{
					console.log("" + error);
				}
				else
				{
					excluirTodosExchangeDeMensagensParaServicos(ch);
					criarQueueExchangeDeMensagensParaServicos(ch);					
					associarCallbackQueueRecebimentoMensagens(ch, "NOTIFICACAO_SERVICO_ONLINE", solicitarServicoDistribuidoCriarQueueDeRecebimentoDeMensagem);
					associarCallbackQueueRecebimentoMensagens(ch, "PUBLICACAO_MENSAGEM", tratarPublicacaoMensagem);
					criarMonitorServicos(ch);
					var servidorHttp = criarServidorHttp(ch);
					criarServidorWebSocket(ch, servidorHttp);
					servidorHttp.listen(PORTA_BARRAMENTO, function()
					{
						console.log("Servidor Http ouvindo conexões em http://" + ip.address() + ":" + PORTA_BARRAMENTO + "... Para sair, pressione CTRL+C.");
					});
					console.log("Aguardando por mensagens do Rabbit... Para sair, pressione CTRL+C.");
				}
			});
		}
	});
}

iniciarServidorBarramentoNode();