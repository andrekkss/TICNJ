angular
.module("sinalControllerApp", [])
.filter('toWord', function()
{
    return function(input)
	{
		if (!input)
		{
			return "";
		}
		var caracteres = input.split("");
		if (caracteres.length > 0)
		{
			caracteres[0] = caracteres[0].toUpperCase();
		}
		for (var i = 1, size = caracteres.length; i< size; i++)
		{
			if (caracteres[i].toUpperCase() === caracteres[i])
			{
				caracteres[i] = " " + caracteres[i];
			}
		}
		return caracteres.join("");
    }
})
.controller("SinalController", function($timeout)
{
	var vm = this;
	vm.urlSocket = "ws://localhost:5000/servicos/displayestadosinal";
	vm.listaEstadoSinal = [];
	vm.estadoConexao = "";
	vm.filtroEstado;
	vm.connectionOk = true;
	vm.partialConnection = true;
	vm.noConnection = true;
	vm.timeout = true;
	
	vm.atualizarFiltro = function()
	{
		vm.filtroEstado = 	(vm.connectionOk ? "OK;": "") +
							(vm.partialConnection ? "PARTIAL_CONNECTION;": "") +
							(vm.noConnection ? "NO_CONNECTION;": "") + 
							(vm.timeout ? "TIMED_OUT;": "");
	};
	
	vm.init = function()
	{
		vm.atualizarFiltro();
		abrirConexaoSocket();
	}
	
	function inicializarAtivo(ativo)
	{
		for (var props in ativo)
		{
			ativo[props] = undefined;
		}
	}

	function abrirConexaoSocket()
	{
		vm.estadoConexao = "Iniciando conexão com o servidor..."
		vm.conexaoSocket = new WebSocket(vm.urlSocket);
		vm.conexaoSocket.onopen = function ()
		{
			$timeout(function()
			{
				vm.estadoConexao = "";
			}, 0);
			var mensagemListarEstadoSinal = 
			{
				"type": "LISTAGEM"
			};
			vm.conexaoSocket.send(JSON.stringify(mensagemListarEstadoSinal));
		};
		vm.conexaoSocket.onmessage = function (message)
		{
			$timeout(function()
			{
				var m = JSON.parse(message.data);
				var listaEstadoDoSinal = m.data;

				vm.listaEstadoSinal = [];
				if (m.type == "MENSAGEM_DE_ERRO")
				{
					vm.estadoConexao = m.data;
				}
				else
				{
					vm.listaEstadoSinal = listaEstadoDoSinal;
				}
			}, 0);
		};
		vm.conexaoSocket.onclose = function ()
		{
			reconectar();
		};
		vm.conexaoSocket.onerror = function (error)
		{
			vm.estadoConexao = "Erro na conexão: " + error;
			reconectar();
		};
	}
	
	function reconectar()
	{
		if (vm.conexaoSocket.reconexaoEmAndamento)
		{
			return;
		}
		vm.conexaoSocket.reconexaoEmAndamento = true;
		vm.conexaoSocket.close();
		if (!vm.estadoConexao)
		{
			vm.estadoConexao = "Conexão perdida... Reconectando novamente em 3segs.";
		}
		$timeout(function()
		{
			vm.conexaoSocket.reconexaoEmAndamento = false;
			abrirConexaoSocket();
		}, 3000);
	}
	
});