angular
.module("daytradeControllerApp", [])
.filter('retiraNomeMetodologia', function()
{
    return function(input)
	{
		if (!input)
		{
			return "";
		}
		return input.replace(/^.*\_(.*)/, "$1"); // retira os caracteres antes do underline que estiver dentro do texto (inclusive o underline)
		
    }
})
.filter('toWord', function()
{
    return function(input)
	{
		if (!input)
		{
			return "";
		}
		var caracteres = input.split("");
		if (caracteres.length > 0)
		{
			caracteres[0] = caracteres[0].toUpperCase();
		}
		for (var i = 1, size = caracteres.length; i< size; i++)
		{
			if (caracteres[i].toUpperCase() === caracteres[i])
			{
				caracteres[i] = " " + caracteres[i];
			}
		}
		return caracteres.join("");
    }
})
.controller("DaytradeController", function($timeout)
{
	var vm = this;
	vm.urlSocket = "ws://localhost:5000/servicos/displaydaytrade";
	vm.listaAtivo = [];
	vm.estadoConexao = ""; 
	vm.timestampUltimaAtualizacao = "";

	vm.init = function()
	{
		abrirConexaoSocket();
	}
	
	function inicializarAtivo(ativo)
	{
		for (var props in ativo)
		{
			ativo[props] = undefined;
		}
	}

	function contarPropriedades(objeto, nomeObjeto)
	{
		if (!objeto.span)
		{
			objeto.span = {};
		}
		if (!objeto[nomeObjeto])
		{
			return;
		}
		var contagem = 0;
		for (var props in objeto[nomeObjeto])
		{
			contagem++;
		}
		if (contagem !== 0)
		{
			objeto.span[nomeObjeto] = contagem;
		}
	}
	
	function abrirConexaoSocket()
	{
		vm.estadoConexao = "Iniciando conexão com o servidor..."
		vm.conexaoSocket = new WebSocket(vm.urlSocket);
		vm.conexaoSocket.onopen = function ()
		{
			$timeout(function()
			{
				vm.estadoConexao = "";
			}, 0);
			var mensagemListarAtivos = 
			{
				"type": "LISTAGEM"
			};
			vm.conexaoSocket.send(JSON.stringify(mensagemListarAtivos));
		};
		
		vm.conexaoSocket.onmessage = function (message)
		{
			$timeout(function()
			{
				var ativoDoSinal = JSON.parse(message.data).data;
				vm.timestampUltimaAtualizacao = "Última atualização: " + JSON.parse(message.data).timestampUltimaAtualizacao;
				var ativoDaLista = null;
				for (var i = 0, size = vm.listaAtivo.length; i < size; i++)
				{
					if (vm.listaAtivo[i].papel === ativoDoSinal.nomePapel)
					{
						ativoDaLista = vm.listaAtivo[i];
						break;
					}
				}
				
				if (ativoDaLista === null)
				{
					ativoDaLista = {};
					vm.listaAtivo.push(ativoDaLista);
				}
				
				ativoDaLista.papel = ativoDoSinal.nomePapel;				
				angular.extend(ativoDaLista, ativoDoSinal);

				formatarClasseExibicaoTela(ativoDaLista);
					
				classificarListaAtivo();
			}, 0);
		};
		vm.conexaoSocket.onclose = function ()
		{
			reconectar();
		};
		vm.conexaoSocket.onerror = function (error)
		{
			vm.estadoConexao = "Erro na conexão: " + error;
			reconectar();
		};
	}
	
	function formatarClasseExibicaoTela(ativo)
	{
		if (ativo.ordemVendaSimulada && ativo.ordemVendaSimulada.inicio)
		{
			ativo.classeExibicao = "vendido";
		}
		else if (ativo.ordemCompraSimulada && ativo.sinalB3)
		{
			if (Number(ativo.sinalB3.ultimoPreco) <= Number(ativo.ordemCompraSimulada.precoIdealCompra))
			{
				ativo.classeExibicao = "ok";
			}
			else
			{
				ativo.classeExibicao = "nao-ok";
			}
		}
		else
		{
			ativo.classeExibicao = "";
		}
	}
	
	function classificarListaAtivo()
	{
		vm.listaAtivo.sort(function(a, b)
		{
			var temOrdemCompraSimulada1 = "NAO";
			var temOrdemCompraSimulada2 = "NAO";
			var inicioOrdemCompraSimulada1 = "0000-00-00 00:00:00";
			var inicioOrdemCompraSimulada2 = "0000-00-00 00:00:00";
			if (a.ordemCompraSimulada && a.ordemCompraSimulada.inicio)
			{
				inicioOrdemCompraSimulada1 = a.ordemCompraSimulada.inicio;
				temOrdemCompraSimulada1 = "SIM";
			}
			if (b.ordemCompraSimulada && b.ordemCompraSimulada.inicio)
			{
				inicioOrdemCompraSimulada2 = b.ordemCompraSimulada.inicio;
				temOrdemCompraSimulada2 = "SIM";
			}				

			var temOrdemVendaSimulada1 = "NAO";
			var temOrdemVendaSimulada2 = "NAO";
			var inicioOrdemVendaSimulada1 = "0000-00-00 00:00:00";
			var inicioOrdemVendaSimulada2 = "0000-00-00 00:00:00";
			if (a.ordemVendaSimulada && a.ordemVendaSimulada.inicio)
			{
				inicioOrdemVendaSimulada1 = a.ordemVendaSimulada.inicio;
				temOrdemVendaSimulada1 = "SIM";
			}
			if (b.ordemVendaSimulada && b.ordemVendaSimulada.inicio)
			{
				inicioOrdemVendaSimulada2 = b.ordemVendaSimulada.inicio;
				temOrdemVendaSimulada2 = "SIM";
			}				

			var chave1 = temOrdemCompraSimulada1 + temOrdemVendaSimulada2 + inicioOrdemCompraSimulada1 + inicioOrdemVendaSimulada1 + b.nomePapel;
			var chave2 = temOrdemCompraSimulada2 + temOrdemVendaSimulada1 + inicioOrdemCompraSimulada2 + inicioOrdemVendaSimulada2 + a.nomePapel;
			return -chave1.localeCompare(chave2);
		});
	}
	
	function reconectar()
	{
		if (vm.conexaoSocket.reconexaoEmAndamento)
		{
			return;
		}
		vm.conexaoSocket.reconexaoEmAndamento = true;
		vm.conexaoSocket.close();
		if (!vm.estadoConexao)
		{
			vm.estadoConexao = "Conexão perdida... Reconectando novamente em 3segs.";
		}
		$timeout(function()
		{
			vm.conexaoSocket.reconexaoEmAndamento = false;
			abrirConexaoSocket();
		}, 3000);
	}
	
});