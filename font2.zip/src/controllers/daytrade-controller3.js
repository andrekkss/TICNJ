angular
.module("daytradeControllerApp", [])
.filter('retiraNomeMetodologia', function()
{
    return function(input)
	{
		if (!input)
		{
			return "";
		}
		return input.replace(/^.*\_(.*)/, "$1"); // retira os caracteres antes do underline que estiver dentro do texto (inclusive o underline)
		
    }
})
.filter('timestamp', function()
{
    return function(input)
	{
		if (!input)
		{
			return "";
		}
		var ano = input.substring(0, 4);
		var mes = input.substring(4, 6);
		var mes = input.substring(4, 6);
		var dia = input.substring(6, 8);
		var hora = input.substring(8, 10);
		var minuto = input.substring(10, 12);
		var segundo = input.substring(12, 14);
		var milesimo = input.substring(14);
		return dia + "-" + mes + "-" + ano + "\t" + hora + ":" + minuto + ":" + segundo;
    }
})
.filter('toWord', function()
{
    return function(input)
	{
		if (!input)
		{
			return "";
		}
		var caracteres = input.split("");
		if (caracteres.length > 0)
		{
			caracteres[0] = caracteres[0].toUpperCase();
		}
		for (var i = 1, size = caracteres.length; i< size; i++)
		{
			if (caracteres[i].toUpperCase() === caracteres[i])
			{
				caracteres[i] = " " + caracteres[i];
			}
		}
		return caracteres.join("");
    }
})
.controller("DaytradeController", function($timeout)
{
	var vm = this;
	vm.urlSocket = "ws://localhost:5000/servicos/displaydaytrade3";
	vm.listaTrade = [];
	vm.estadoConexao = ""; 
	vm.timestampUltimaAtualizacao = "";
	vm.timestampAtualAtualizacao = "";
	vm.timestampAnteriorAtualizacao = "";

	vm.init = function()
	{
		abrirConexaoSocket();
	}
	
	function abrirConexaoSocket()
	{
		vm.estadoConexao = "Iniciando conexão com o servidor..."
		vm.conexaoSocket = new WebSocket(vm.urlSocket);
		vm.conexaoSocket.onopen = function ()
		{
			$timeout(function()
			{
				vm.estadoConexao = "";
			}, 0);
			var mensagemListarAtivos = 
			{
				"type": "LISTAR_TRADES"
			};
			vm.conexaoSocket.send(JSON.stringify(mensagemListarAtivos));
		};
		
		vm.conexaoSocket.onmessage = function (message)
		{
			$timeout(function()
			{
				var m = JSON.parse(message.data);
				if (m.type == "LIMPAR_CACHE")
				{
					vm.timestampUltimaAtualizacao = "Última atualização: ";
					vm.listaTrade = [];
				}
				else if (m.type == "TRADE")
				{
					var trade = m.data;

					vm.timestampAnteriorAtualizacao = vm.timestampAtualAtualizacao;					
					var t = trade.timestampUltimaAtualizacao;
					vm.timestampAtualAtualizacao = t.substring(6, 10) + t.substring(3, 5) + t.substring(0, 2) + t.substring(14, 16) + t.substring(17, 19) + t.substring(20, 22);
					
					if (vm.timestampAtualAtualizacao > vm.timestampAnteriorAtualizacao)
					{
						vm.timestampUltimaAtualizacao = "Última atualização: " + trade.timestampUltimaAtualizacao;
					}
					for (var i = 0; i < vm.listaTrade.length; i++)
					{
						if (vm.listaTrade[i].ativo && trade.ativo && vm.listaTrade[i].ativo.nomePapel == trade.ativo.nomePapel)
						{
							vm.listaTrade.splice(i, 1);
						}
					}
					vm.listaTrade.push(trade);
					formatarClasseExibicaoTela(trade);
				}
				else if (m.type == "MENSAGEM_DE_ERRO")
				{
					vm.estadoConexao = m.data;
					vm.listaTrade = [];
				}
				classificarListaAtivo();
			}, 0);
		};
		vm.conexaoSocket.onclose = function ()
		{
			reconectar();
		};
		vm.conexaoSocket.onerror = function (error)
		{
			vm.estadoConexao = "Erro na conexão: " + error;
			reconectar();
		};
	}
	
	function formatarClasseExibicaoTela(trade)
	{
		if (trade.ordemVenda && trade.ordemVenda.timestampOrdemAutomatico)
		{
			trade.classeExibicao = "vendido";
		}
		else if (trade.ordemCompra && trade.ativo)
		{
			if (Number(trade.ativo.ultimoPreco) <= Number(trade.ordemCompra.valorPrecoNegociacaoIdeal))
			{
				trade.classeExibicao = "ok";
			}
			else
			{
				trade.classeExibicao = "nao-ok";
			}
		}
		else
		{
			trade.classeExibicao = "";
		}
	}
	
	function classificarListaAtivo()
	{
		vm.listaTrade.sort(function(a, b)
		{
			var temOrdemCompra1 = "NAO";
			var temOrdemCompra2 = "NAO";
			var inicioOrdemCompra1 = "00000000000000000";
			var inicioOrdemCompra2 = "00000000000000000";
			if (a.ordemCompra && a.ordemCompra.timestampOrdemAutomatico)
			{
				inicioOrdemCompra1 = a.ordemCompra.timestampOrdemAutomatico;
				temOrdemCompra1 = "SIM";
			}
			if (b.ordemCompra && b.ordemCompra.timestampOrdemAutomatico)
			{
				inicioOrdemCompra2 = b.ordemCompra.timestampOrdemAutomatico;
				temOrdemCompra2 = "SIM";
			}				

			var temOrdemVenda1 = "NAO";
			var temOrdemVenda2 = "NAO";
			var inicioOrdemVenda1 = "00000000000000000";
			var inicioOrdemVenda2 = "00000000000000000";
			if (a.ordemVenda && a.ordemVenda.timestampOrdemAutomatico)
			{
				inicioOrdemVenda1 = a.ordemVenda.timestampOrdemAutomatico;
				temOrdemVenda1 = "SIM";
			}
			if (b.ordemVenda && b.ordemVenda.timestampOrdemAutomatico)
			{
				inicioOrdemVenda2 = b.ordemVenda.timestampOrdemAutomatico;
				temOrdemVenda2 = "SIM";
			}				

			var nomePapel2 = "";
			var nomePapel1 = "";
			if (a.ativo)
			{
				nomePapel1 = a.ativo.nomePapel;
			}
			if (b.ativo)
			{
				nomePapel2 = b.ativo.nomePapel;
			}
			
			var chave1 = temOrdemCompra1 + temOrdemVenda2 + inicioOrdemCompra1 + inicioOrdemVenda1 + nomePapel2;
			var chave2 = temOrdemCompra2 + temOrdemVenda1 + inicioOrdemCompra2 + inicioOrdemVenda2 + nomePapel1;
			return -chave1.localeCompare(chave2);
		});
	}
	
	function reconectar()
	{
		if (vm.conexaoSocket.reconexaoEmAndamento)
		{
			return;
		}
		vm.conexaoSocket.reconexaoEmAndamento = true;
		vm.conexaoSocket.close();
		if (!vm.estadoConexao)
		{
			vm.estadoConexao = "Conexão perdida... Reconectando novamente em 3segs.";
		}
		$timeout(function()
		{
			vm.conexaoSocket.reconexaoEmAndamento = false;
			abrirConexaoSocket();
		}, 3000);
	}
	
});