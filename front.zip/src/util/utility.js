export const toWord = ( input ) => {
    if (!input)
		{
			return '';
		}
		let caracteres = input.split('');
		if (caracteres.length > 0)
		{
			caracteres[0] = caracteres[0].toUpperCase();
		}
		for (var i = 1, size = caracteres.length; i< size; i++)
		{
			if (caracteres[i].toUpperCase() === caracteres[i])
			{
				caracteres[i] = " " + caracteres[i];
			}
		}
    return caracteres.join('');
}

export const exitName = ( input ) => {
    return !input ? "" : input.replace(/^.*\_(.*)/, "$1"); // retira os caracteres antes do underline que estiver dentro do texto (inclusive o underline)
}