const caminhoPropertyServidor = require('PropertyServidor');
const caminhoPropertyLocal = require('PropertyLocal');

const ambiente = process.env.REACT_APP_ENV || process.env.NODE_ENV || '';

console.log(`[ AMBIENTE - ${ambiente} ]`);

const config = ambiente === 'server' ? caminhoPropertyServidor : caminhoPropertyLocal;

console.log(`[ CAMINHO - ${JSON.stringify(config)} ]`);

export default { ...config };