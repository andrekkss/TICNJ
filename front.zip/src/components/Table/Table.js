import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import { strict } from 'assert';

const styles = theme => ({
  root: {
    width: '100%',
    marginTop: theme.spacing.unit * 3,
    overflowX: 'auto',
  },
  table: {
    minWidth: 700,
  },
});

class MyTable extends Component {
  render(){
  const { rows } = this.props;
  return (
    <Paper className={styles.root}>
        <Table className={styles.table}>
        <TableHead>
            <TableRow>
            <TableCell>Nome</TableCell>
            <TableCell>Descrição</TableCell>
            <TableCell>Caminho de Acesso</TableCell>
            <TableCell>Servidores</TableCell>
            </TableRow>
        </TableHead>
        <TableBody>
            {Object.entries(rows.data).map(([key, data]) => {
            return(
                <TableRow key={key}>
                <TableCell component="th" scope="row">
                {data.nome}
                </TableCell>
                <TableCell align="left">{data.descricao}</TableCell>
                <TableCell align="left">{key}</TableCell>
                <TableCell align="right">{data.servidores[0].url}</TableCell>
            </TableRow>
            );
            })}
        </TableBody>
        </Table>
    </Paper>
    );
  }
}

MyTable.propTypes = {
  rows: PropTypes.array.isRequired
};

export default MyTable;
