import React, {  } from 'react';
import PrimarySearchAppBar from '../components/TopBar/topbarComponent';

const Home = () => (
    <div>
      <PrimarySearchAppBar />
    </div>
  );
  

export default Home;