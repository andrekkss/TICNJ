import React, { Component } from 'react';
import MyTable from '../../components/Table/Table';

class Publicador extends Component {
  constructor(props){
    super(props);
    this.state ={
      lista: {  
        data: {}
        }
    };
  }

  componentDidMount(){
    this.socket = new WebSocket("ws://localhost:5000/servicos/monitor");

    this.socket.addEventListener('message', (message) => {
        let lista = this.state.lista;
        lista = JSON.parse(message.data);
        this.setState({ lista });
    });
    
    setTimeout( _ => {
      this.socket.close();
    }, 2000 )
  }
  
  render() {
    const { lista } = this.state;
    
    return (
      <div>
         <MyTable rows={lista}/>
      </div>
    );
  }
}

export default Publicador;
