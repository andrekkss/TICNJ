import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter } from 'react-router-dom';
import { Provider } from 'react-redux';

import config from './config';
import store from './store/index';

import App from './App';
import * as serviceWorker from './serviceWorker';

import JssProvider from 'react-jss/lib/JssProvider';
import { create } from 'jss';

import { createGenerateClassName, jssPreset } from '@material-ui/core/styles';
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';

const theme = createMuiTheme({
    palette: {
      primary: {
        light: '#6573c3',
        main: '#3f51b5',
        dark: '#2c387e',
        contrastText: '#fff',
      },
      secondary: {
        light: '#ffcf33',
        main: '#ffc400',
        dark: '#b28900',
        contrastText: '#000',
      },
    },
  });

const generateClassName = createGenerateClassName();
const jss = create({
  ...jssPreset(),
  // We define a custom insertion point that JSS will look for injecting the styles in the DOM.
  insertionPoint: document.getElementById('jss-insertion-point'),
});

const app = (
    <JssProvider jss={jss} generateClassName={generateClassName}>
        <MuiThemeProvider theme={theme}>
            <Provider store={store}>
            <BrowserRouter basename={'/'}>
                <App />
            </BrowserRouter>
            </Provider>
        </MuiThemeProvider>
    </JssProvider>
);
ReactDOM.render(app, document.getElementById('root'));

serviceWorker.unregister();