### `configuração`

Para funcionamento correto, colocar as seguintes váriaveis no webpack(node_modules/react-scripts/config): 

#import
const PropertiesReader = require('properties-reader');

#properties
const caminhoPropertyServidor = PropertiesReader('../../configuracao/servidor.properties')._properties;
const caminhoPropertyLocal = PropertiesReader('../../configuracao/local.properties')._properties;

#externals
colocar na linha: 186

externals: {
    'PropertyServidor': JSON.stringify(caminhoPropertyServidor),
    'PropertyLocal': JSON.stringify(caminhoPropertyLocal),
}

### `npm run local`

Rodar local.